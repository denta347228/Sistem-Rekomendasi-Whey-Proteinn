
 
<nav class="navbar navbar-expand-sm navbar-dark bg-dark">
  <div class="container-fluid">
     <a class="navbar-brand" href="#">
    <img src="<?php base_url() ?>assets/dist/img/unsri.png" alt="logo" style="width:100px;">
  </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mynavbar">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="mynavbar">
        <ul class="navbar-nav me-auto">
      
         <li class="nav-item">
          <h5 class="nav-link""> Sistem Pendukung Keputusan </h5>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="https://www.instagram.com/dentamustofa/"> Survei </a>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="<?= base_url('semua') ?>">Data Whey Protein</a>
        </li>
      
      </ul>

      <form class="d-flex">
        <!-- <input class="form-control me-2" type="text" placeholder="Search"> -->
       <!--  <button class="btn btn-primary" type="button">Search</button> -->
      </form>
    </div>
  </div>
</nav>
  
