<?php
session_start();

defined('BASEPATH') or exit('No direct script access allowed');

class C_dashboard extends CI_Controller
{

  public function __Construct()
  {
    parent::__construct();
    $this->load->model('M_dashboard');
  
  }

  public function index()
  {

    // LOAD VIEW
    $this->load->view('layout/head');
    $this->load->view('layout/navbar');
    $this->load->view('dashboard/cover');
    $this->load->view('layout/footer');
  }

  public function predict()
  {


    $this->load->view('layout/head');
    $this->load->view('layout/navbar');
    $this->load->view('dashboard/Tampil');
    $this->load->view('layout/footer');
  }
  public function next()
  {
    if (isset($_POST['input'])) {
      $SPrio = $this->M_dashboard->set_priority();
      $_SESSION["SPrio"] = $SPrio;
      $this->load->view('layout/head');
      $this->load->view('layout/navbar');
      $this->load->view('dashboard/Range');
      $this->load->view('layout/footer');

      // print_r($SUser);
    }
  }

  public function Semua()
  {
    $temp = $this->M_dashboard->setdata();
    $rawTest = [];
    for ($i = 0; $i < count($temp); $i++) {
      for ($j = 0; $j < count($temp[0]); $j++) {
        if ($j == 0) {
          $rawTest[$i][$j] = $temp[$i]['Nama'];
        } elseif ($j == 1) {
          $rawTest[$i][$j] = $temp[$i]['Cost'];
        } elseif ($j == 2) {
          $rawTest[$i][$j] = $temp[$i]['Protein'];
        } elseif ($j == 3) {
          $rawTest[$i][$j] = $temp[$i]['Calories'];
        } elseif ($j == 4) {
          $rawTest[$i][$j] = $temp[$i]['Sugar'];
        } elseif ($j == 5) {
          $rawTest[$i][$j] = $temp[$i]['Cholestrol'];
        } elseif ($j == 6) {
          $rawTest[$i][$j] = $temp[$i]['Sodium'];
        } else {
          $rawTest[$i][$j] = $temp[$i]['Carbohidrat'];
        }
      }
    }

    //print_r($rawTest);
    $datawhey['rawTest'] = $rawTest;
    $this->load->view('layout/head');
    $this->load->view('layout/navbar');
    $this->load->view('dashboard/alldata', $datawhey);
    $this->load->view('layout/footer');
  }
  public function input()
  {

    if (isset($_POST['input'])) {
      $SPrio = $_SESSION["SPrio"];
      $SUser = $this->M_dashboard->set_user();
    }


    $temp = $this->M_dashboard->setdata();
    $rawTest1 = [];
    for ($i = 0; $i < count($temp); $i++) {
      for ($j = 0; $j < count($temp[0]); $j++) {
        if ($j == 0) {
          $rawTest1[$i][$j] = $temp[$i]['Nama'];
        } elseif ($j == 1) {
          $rawTest1[$i][$j] = $temp[$i]['Cost'];
        } elseif ($j == 2) {
          $rawTest1[$i][$j] = $temp[$i]['Protein'];
        } elseif ($j == 3) {
          $rawTest1[$i][$j] = $temp[$i]['Calories'];
        } elseif ($j == 4) {
          $rawTest1[$i][$j] = $temp[$i]['Sugar'];
        } elseif ($j == 5) {
          $rawTest1[$i][$j] = $temp[$i]['Cholestrol'];
        } elseif ($j == 6) {
          $rawTest1[$i][$j] = $temp[$i]['Sodium'];
        } else {
          $rawTest1[$i][$j] = $temp[$i]['Carbohidrat'];
        }
      }
   }

    $bobot = $this->M_dashboard->set_bobot($SPrio); //priority awal
     // $rawTest1  = $this->M_dashboard->getTsv("Skripsi.txt");

    $bobot_sub_kriteria1 = $this->M_dashboard->bobot_sub_kriteria(3);


    $rawTest2 = $this->M_dashboard->sub_kriteria($rawTest1, $bobot_sub_kriteria1);

    //$this->M_dashboard->test($SPrio);
    $max = $this->M_dashboard->max($rawTest2);
    $min = $this->M_dashboard->min($rawTest2);

    // $this->M_dashboard->utility($rawTest2, $max, $min, $bobot);

    $utility_t = $this->M_dashboard->utility($rawTest2, $max, $min, $bobot);


    $utility_u = $this->M_dashboard->utility_user($max, $min, $bobot, $SUser, $bobot_sub_kriteria1);

    // print_r($utility_u);

    $er = 0;
    for ($i = 0; $i < count($utility_u); $i++) {
      $er += $utility_u[$i];
      // print_r($er);
    }
    $TempS = [];
    $SetNilai = $this->M_dashboard->set_nilai($utility_t);
    // print_r($y);
    $CekNilai = $this->M_dashboard->check_range($SetNilai, $er);
    // print_r($po);
    $TempS = $SetNilai;
    sort($SetNilai);
    sort($CekNilai);
    $tempAkhir = $this->M_dashboard->sorting($CekNilai, $TempS);


    $data['temp']    = $tempAkhir;
    $data['utility_t'] = $rawTest1;
    $data['TempS']       = $TempS;
    $data['utility_r'] = $utility_t;
    $data['rawTest2'] = $rawTest2;
    $data['rawTest1'] = $rawTest1;


    $this->load->view('layout/head');
    $this->load->view('layout/navbar');
    $this->load->view('dashboard/Hasil', $data);
    $this->load->view('layout/footer');
  }
}


/* End of file Dasboard.php */
/* Location: ./application/controllers/Dasboard.php */