<?php
class smarter
{
  
  function __construct($t, $r, $y, $p, $z, $toy)
  {
    $this->TempM = $t;//e
    $this->TempB = $r;//u
    $this->mak = $y;//q
    $this->men = $p;//w
    $this->bob = $z;//v
     if ($toy == 0) {
     $this->SubK();  
     }
     elseif ($toy == 2) {
       $this->utility_u();
     }
     else {
      $this->utility_t();
     }


    
    
   // print_r($this->e);
  }
  public function SubK()//rr
  {
    $rawTest = $this->TempM;
    $bobot_sub_kriteria1 = $this->TempB;
    for ($i = 0; $i < count($rawTest); $i++) {// jalani baris
      for ($j = 1; $j < count($rawTest[0]); $j++) {///jalani kolom
        if ($j==1) {
          if ($rawTest[$i][$j]>=500000 && $rawTest[$i][$j]<=900000)
           {
             $rawTest[$i][$j] = $bobot_sub_kriteria1[0]; 
          }
          elseif ($rawTest[$i][$j]>900000 && $rawTest[$i][$j]<=1500000) {
           $rawTest[$i][$j] = $bobot_sub_kriteria1[1]; 
          }
          else {
           $rawTest[$i][$j] = $bobot_sub_kriteria1[2]; 
          }
        }
        elseif ($j==2) {
          if ($rawTest[$i][$j]>=20 && $rawTest[$i][$j] <=24) {
             $rawTest[$i][$j] = $bobot_sub_kriteria1[1]; 
          }
          elseif ($rawTest[$i][$j]>=10 && $rawTest[$i][$j]<=19) {
           $rawTest[$i][$j] = $bobot_sub_kriteria1[2]; 
          }
          else {
           $rawTest[$i][$j] = $bobot_sub_kriteria1[0]; 
          }
        }
        elseif ($j==3) {
          if ($rawTest[$i][$j]>=80 && $rawTest[$i][$j] <=100) {
             $rawTest[$i][$j] = $bobot_sub_kriteria1[0]; 
          }
          elseif ($rawTest[$i][$j]>=101 && $rawTest[$i][$j]<=150) {
           $rawTest[$i][$j] = $bobot_sub_kriteria1[1]; 
          }
          else {
           $rawTest[$i][$j] = $bobot_sub_kriteria1[2]; 
          }
        }
         elseif ($j==4) {
          if ($rawTest[$i][$j]>=0 && $rawTest[$i][$j] <=3) {
             $rawTest[$i][$j] = $bobot_sub_kriteria1[0]; 
          }
          elseif ($rawTest[$i][$j]>=4 && $rawTest[$i][$j]<=5) {
           $rawTest[$i][$j] = $bobot_sub_kriteria1[1]; 
          }
          else {
           $rawTest[$i][$j] = $bobot_sub_kriteria1[2]; 
          }
        }
        elseif ($j==5) {
          if ($rawTest[$i][$j]>=0 && $rawTest[$i][$j] <=15) {
             $rawTest[$i][$j] = $bobot_sub_kriteria1[0]; 
          }
          elseif ($rawTest[$i][$j]>=16 && $rawTest[$i][$j]<=50) {
           $rawTest[$i][$j] = $bobot_sub_kriteria1[1]; 
          }
          else {
           $rawTest[$i][$j] = $bobot_sub_kriteria1[2]; 
          }
        }
        elseif ($j==6) {
          if ($rawTest[$i][$j]>=0 && $rawTest[$i][$j] <=100) {
             $rawTest[$i][$j] = $bobot_sub_kriteria1[0]; 
          }
          elseif ($rawTest[$i][$j]>=101 && $rawTest[$i][$j]<=150) {
           $rawTest[$i][$j] = $bobot_sub_kriteria1[1]; 
          }
          else {
           $rawTest[$i][$j] = $bobot_sub_kriteria1[2]; 
          }
        }
        elseif ($j==7) {
          if ($rawTest[$i][$j]>=4 && $rawTest[$i][$j] <=5) {
             $rawTest[$i][$j] = $bobot_sub_kriteria1[1]; 
          }
          elseif ($rawTest[$i][$j]>=1 && $rawTest[$i][$j]<=3) {
           $rawTest[$i][$j] = $bobot_sub_kriteria1[2]; 
          }
          else {
           $rawTest[$i][$j] = $bobot_sub_kriteria1[0]; 
          }
        }
      }
    }

    $this->normalisasi = $rawTest;
  }

  public function utility_t()
  {
    $rawTest = $this->TempM;
    $max = $this->mak;
    $min = $this->men;
    $bobot = $this->bob;
    //print_r($bobot);
    for ($i=0; $i < count($rawTest); $i++) { 
      for ($j=1; $j < count($rawTest[0]); $j++) { 
        $utility;
        if ($j==1) {
          $utility = ($rawTest[$i][$j] - $min[$j-1])/($max[$j-1]-$min[$j-1]);
          $rawTest[$i][$j] = $utility*$bobot[0];
        }
        elseif ($j==2) {
          $utility = ($rawTest[$i][$j] - $min[$j-1])/($max[$j-1]-$min[$j-1]);
          $rawTest[$i][$j] = $utility*$bobot[1];
        }
        elseif ($j==3) {
          $utility = ($rawTest[$i][$j] - $min[$j-1])/($max[$j-1]-$min[$j-1]);
          $rawTest[$i][$j] = $utility*$bobot[2];
        }
        elseif ($j==4) {
          $utility = ($rawTest[$i][$j] - $min[$j-1])/($max[$j-1]-$min[$j-1]);
          $rawTest[$i][$j] = $utility*$bobot[3];
        }
        elseif ($j==5) {
          $utility = ($rawTest[$i][$j] - $min[$j-1])/($max[$j-1]-$min[$j-1]);
          $rawTest[$i][$j] = $utility*$bobot[4];
        }
        elseif ($j==6) {
          $utility = ($rawTest[$i][$j] - $min[$j-1])/($max[$j-1]-$min[$j-1]);
          $rawTest[$i][$j] = $utility*$bobot[5];
        }
        else {
         $utility = ($rawTest[$i][$j] - $min[$j-1])/($max[$j-1]-$min[$j-1]);
         $rawTest[$i][$j] = $utility*$bobot[6]; 
        }
      }
    }
  $this->utl = $rawTest;

  }
  
  public function utility_u()
  {
    $qq = $this->TempM;
    $max = $this->mak;
    $min = $this->men;
    $bobot = $this->bob;
    $bobot_sub_kriteria1 = $this->TempB;
    $tt = [];
  for ($i=0; $i < count($qq); $i++) {
      $utility; 
      if ($i==0) {
          $utility = ($bobot_sub_kriteria1[$qq[$i]-1] - $min[$i])/($max[$i]-$min[$i]);
          $tt[] = $utility*$bobot[$i];
        }
        elseif ($i==1) {
          $utility = ($bobot_sub_kriteria1[$qq[$i]-1] - $min[$i])/($max[$i]-$min[$i]);
          $tt[] = $utility*$bobot[$i];
        }
        elseif ($i==2) {
          $utility = ($bobot_sub_kriteria1[$qq[$i]-1] - $min[$i])/($max[$i]-$min[$i]);
          $tt[] = $utility*$bobot[$i];
        }
        elseif ($i==3) {
          $utility = ($bobot_sub_kriteria1[$qq[$i]-1] - $min[$i])/($max[$i]-$min[$i]);
          $tt[] = $utility*$bobot[$i];
        }
        elseif ($i==4) {
          $utility = ($bobot_sub_kriteria1[$qq[$i]-1] - $min[$i])/($max[$i]-$min[$i]);
          $tt[] = $utility*$bobot[$i];
        }
        elseif ($i==5) {
          $utility = ($bobot_sub_kriteria1[$qq[$i]-1] - $min[$i])/($max[$i]-$min[$i]);
          $tt[] = $utility*$bobot[$i];
        }
        else {
          $utility = ($bobot_sub_kriteria1[$qq[$i]-1] - $min[$i])/($max[$i]-$min[$i]);
         $tt[] = $utility*$bobot[$i]; 
        }
    }
    $this->utl_usr = $tt;
  }

}
